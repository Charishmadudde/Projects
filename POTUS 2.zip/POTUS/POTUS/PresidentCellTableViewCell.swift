//
//  PresidentCellTableViewCell.swift
//  POTUS
//
//  Created by Revanth Reddy Dadi on 23/11/17.
//  Copyright © 2017 NIU. All rights reserved.
//

import UIKit

class PresidentCellTableViewCell: UITableViewCell {
    
    @IBOutlet weak var presidentImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var politicalPartyLabel: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
