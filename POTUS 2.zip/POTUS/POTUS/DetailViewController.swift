//
//  DetailViewController.swift
//  POTUS
//
//  Created by Charishma Dudde(Z1810220) & Bhamati Pravallika Kuchibotla(Z1804769) on 08/11/17.
//  Copyright © 2017 NIU. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var numberLabel: UILabel!
    @IBOutlet weak var termLabel: UILabel!
    @IBOutlet weak var nickNameLabel: UILabel!
    @IBOutlet weak var politicalPartyLabel: UILabel!
    

    func configureView() {
        // Update the user interface for the detail item.
        if let detail = detailItem {
            if let label = nameLabel {
                label.text = detail.name
            }
            if let label = numberLabel {
                let number = detail.number
                
                let termString = number.ordinal + " President of the United States"
                
                label.text = termString
            }
            if let label = termLabel {
                
                let startDate = detail.startDate
                let endDate = detail.endDate
                
                let term = "( " + startDate + " to " + endDate + " )"
                
                label.text = term
            }
            if let label = nickNameLabel {
                label.text = detail.nickName
            }
            if let label = politicalPartyLabel {
                label.text = detail.politicalParty
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        configureView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    var detailItem: President? {
        didSet {
            // Update the view.
            configureView()
        }
    }


}

