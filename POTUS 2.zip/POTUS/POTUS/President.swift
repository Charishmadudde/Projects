//
//  President.swift
//  POTUS
//
//  Created by Charishma Dudde(Z1810220) & Bhamati Pravallika Kuchibotla(Z1804769) on 08/11/17.
//  Copyright © 2017 NIU. All rights reserved.
//

import Foundation

class President {
    var name = ""
    var number = Int()
    var startDate = ""
    var endDate = ""
    var nickName = ""
    var politicalParty = ""
    var url = ""
    
    init(name: String, number: Int, startDate: String, endDate: String, nickName: String, politicalParty: String, url: String) {
        self.name = name
        self.number = number
        self.startDate = startDate
        self.endDate = endDate
        self.nickName = nickName
        self.politicalParty = politicalParty
        self.url = url
    }
}
