//
//  MasterViewController.swift
//  POTUS
//
//  Created by Charishma Dudde(Z1810220) & Bhamati Pravallika Kuchibotla(Z1804769) on 08/11/17.
//  Copyright © 2017 NIU. All rights reserved.
//

import UIKit

class MasterViewController: UITableViewController, UISearchControllerDelegate, UISearchBarDelegate, UISearchResultsUpdating {

    var detailViewController: DetailViewController? = nil
    var objects = [President]()
    var filteredObjects = [President]()
    
    let searchController = UISearchController(searchResultsController: nil)

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        navigationItem.leftBarButtonItem = editButtonItem

        //let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(insertNewObject(_:)))
        //navigationItem.rightBarButtonItem = addButton
        if let split = splitViewController {
            let controllers = split.viewControllers
            detailViewController = (controllers[controllers.count-1] as! UINavigationController).topViewController as? DetailViewController
        }
        
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        searchController.delegate = self
        definesPresentationContext = true
        tableView.tableHeaderView = searchController.searchBar
        searchController.searchBar.delegate = self
        
        searchController.searchBar.scopeButtonTitles = ["All", "Democrat", "Republican", "Whig"]
        
        downloadJSONData()
    }

    override func viewWillAppear(_ animated: Bool) {
        clearsSelectionOnViewWillAppear = splitViewController!.isCollapsed
        super.viewWillAppear(animated)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func searchBarIsEmpty() -> Bool {
        return searchController.searchBar.text?.isEmpty ?? true
    }
    
    func isFiltering() -> Bool {
        let searchBarScopeIsFiltering = searchController.searchBar.selectedScopeButtonIndex != 0
        return searchController.isActive && (!searchBarIsEmpty() || searchBarScopeIsFiltering)
    }
    
    func filterContentForSearchText(_ searchText: String, scope: String = "All") {
        
        filteredObjects = objects.filter { character in
            let doesCategoryMatch = (scope == "All") || (character.politicalParty == scope)
            
            if searchBarIsEmpty() {
                return doesCategoryMatch
            } else {
                return doesCategoryMatch &&  character.name.lowercased().contains(searchText.lowercased())
            }
        }
        
        tableView.reloadData()
    }

    // MARK: - Segues

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            if let indexPath = tableView.indexPathForSelectedRow {
                
                let president: President
                if isFiltering() {
                    president = filteredObjects[indexPath.row]
                } else {
                    president = objects[indexPath.row]
                }
                
                let controller = (segue.destination as! UINavigationController).topViewController as! DetailViewController
                controller.detailItem = president
                controller.navigationItem.leftBarButtonItem = splitViewController?.displayModeButtonItem
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }

    // MARK: - Table View

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isFiltering() {
            return filteredObjects.count
        } else {
            return objects.count
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! PresidentCellTableViewCell

        let president: President
        if isFiltering() {
            president = filteredObjects[indexPath.row]
        } else {
            president = objects[indexPath.row]
        }
        
    ImageProvider.sharedInstance.imageWithURLString(president.url) {
            (image: UIImage?) in
            cell.presidentImageView!.image = image
        }
        
        cell.nameLabel!.text = president.name
        cell.politicalPartyLabel!.text = president.politicalParty
        return cell
    }

    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            objects.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
    }
    
    // Download JSON data
    func downloadJSONData() {
        
        let session = URLSession.shared
        
        guard let url = URL(string: "https://www.prismnet.com/~mcmahon/CS321/presidents.json") else {
            // Handle invalid URL error
            showAlert("Invalid URL for JSON data")
            return
        }
        
        weak var weakSelf = self
        
        let task = session.dataTask(with: url) {
            (data, response, error) in
            // The response is a HTTPURLResponse, so the app should check for
            // unexpected status codes
            let httpResponse = response as? HTTPURLResponse
            
            if httpResponse!.statusCode != 200 {
                // Handle error
                weakSelf!.showAlert("HTTP error: status code \(httpResponse!.statusCode).")
            } else if (data == nil && error != nil) {
                // Handle error
                weakSelf!.showAlert("No data downloaded.")
            } else {
                // Download succeeded
                let array: [AnyObject]
                
                do {
                    array = try JSONSerialization.jsonObject(with: data!, options: []) as! [AnyObject]
                } catch _ {
                    weakSelf!.showAlert("Unable to parse JSON data.")
                    return
                }
                
                for dictionary in array {
                    let name = dictionary["Name"] as! String
                    let number = dictionary["Number"] as! Int
                    let startDate = dictionary["Start Date"] as! String
                    let endDate = dictionary["End Date"] as! String
                    let nickName = dictionary["Nickname"] as! String
                    let politicalParty = dictionary["Political Party"] as! String
                    let url = dictionary["URL"] as! String
                    
                    weakSelf!.objects.append(President(name: name, number: number, startDate: startDate, endDate: endDate, nickName: nickName, politicalParty: politicalParty, url: url))
                }
                
                weakSelf!.objects.sort {
                    return $0.number < $1.number
                }
                
                DispatchQueue.main.async {
                    weakSelf!.tableView!.reloadData()
                }
            }
        }
        
        task.resume()
    }
    
    // Show alert controller to handle error
    func showAlert(_ message: String) {
        
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        
        DispatchQueue.main.async {
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        let searchBar = searchController.searchBar
        let scope = searchBar.scopeButtonTitles![searchBar.selectedScopeButtonIndex]
        
        filterContentForSearchText(searchController.searchBar.text!, scope: scope)
    }
    
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        filterContentForSearchText(searchBar.text!, scope: searchBar.scopeButtonTitles![selectedScope])
    }


}

