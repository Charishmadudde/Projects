//
//  ManagerhomeViewController.swift
//  samplegrad
//
//  Created by Ios on 12/07/17.
//  Copyright © 2017 charishma bhamati. All rights reserved.
//
/*********************************************************************************************
 GRADUATE PROJECT - AUTHORIZATION SERVICES
 Group       : Charishma Dudde(Z1810220) and Bhamati Pravallika Kuchibhotla(Z1804769)
 
 Purpose     : This project which is an Event management app demonstrates one of the key concepts of Authorization services which is Authentication. Authentication means providing credentials to access the application. Here in this app, 2 roles are presented. Manager and staff. Manager can login and can create events and check events. Staff can log in and and check events assigned to him.
 
 ********************************************************************************************/

import UIKit

class ManagerhomeViewController: UIViewController {
   
    

    override func viewDidLoad() {
        super.viewDidLoad()
       
        
       self.navigationController?.title = "Welcome Manager"
       
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
  
    //redirects to login page if user chlick log out

    
    @IBAction func Logout_Clicked(_ sender: Any) {
self.performSegue(withIdentifier: "ManagerLogOutToLogin", sender: sender)
        
        
    }

    
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier=="MgrToLIst"{
            
                let eventView=segue.destination as! TableViewController
                eventView.navigationItem.title="Event Lists"
                                
       
            
        }
        
   
 

}
}
