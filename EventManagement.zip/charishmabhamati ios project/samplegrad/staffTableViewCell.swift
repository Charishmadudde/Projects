//
//  staffTableViewCell.swift
//  samplegrad
//
//  Created by Ios on 4/15/17.
//  Copyright © 2017 charishma bhamati. All rights reserved.
//
/*********************************************************************************************
 GRADUATE PROJECT - AUTHORIZATION SERVICES
 Group       : Charishma Dudde(Z1810220) and Bhamati Pravallika Kuchibhotla(Z1804769)
 
 Purpose     : This project which is an Event management app demonstrates one of the key concepts of Authorization services which is Authentication. Authentication means providing credentials to access the application. Here in this app, 2 roles are presented. Manager and staff. Manager can login and can create events and check events. Staff can log in and and check events assigned to him.
 
 ********************************************************************************************/
import UIKit

class staffTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    @IBOutlet weak var eventTimelabel: UILabel!

    @IBOutlet weak var Eventname: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
