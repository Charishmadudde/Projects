//
//  LoginViewController.swift
//  samplegrad
//
//  Created by Ios on 12/08/17.
//  Copyright © 2017 charishma bhamati. All rights reserved.
//
/*********************************************************************************************
 GRADUATE PROJECT - AUTHORIZATION SERVICES
 Group       : Charishma Dudde(Z1810220) and Bhamati Pravallika Kuchibhotla(Z1804769)
 
 Purpose     : This project which is an Event management app demonstrates one of the key concepts of Authorization services which is Authentication. Authentication means providing credentials to access the application. Here in this app, 2 roles are presented. Manager and staff. Manager can login and can create events and check events. Staff can log in and and check events assigned to him.
 
 ********************************************************************************************/
import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
//        self.loadViewIfNeeded()
//self.viewWillAppear(true)
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.loadViewIfNeeded()
        //self.viewWillAppear(true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBOutlet weak var EmailidTextfiled: UITextField!
    @IBOutlet weak var passwordTextFiled: UITextField!
    
    // this function pops the keyboard when the control is on the amount texfield
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    
    //this function dismisses the keyboard when user presses the return key
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        EmailidTextfiled.resignFirstResponder()
        passwordTextFiled.resignFirstResponder()
        
        return true
    }
    
    
    //When login button is clicked then it goes to userLogin php where the credentials ar checked and from that php service, success is returned if uder is found, returns failure if not. So according to the php services response the view is redirected to manager view if user is manager and to staff view if credentials belong to staff
    
    @IBAction func Login_ButtomClicked(_ sender: UIButton) {
        
        let useremail = EmailidTextfiled.text!
        let userpassword = passwordTextFiled.text!
        
            // Check if user entered bothe the details, if not alert is diplayed to enter all fields
        if((userpassword.isEmpty) || (useremail.isEmpty)){
            displayMyAlertMessage(usermessage: "All Fields are required")

            return
        }

        
        //Send data to server side
        
        let myUrl = URL(string: "http://students.cs.niu.edu/~z1810220/ios/userLogin.php")
        var request = URLRequest(url: myUrl!)
        request.httpMethod = "POST"
        
        
       
        let postString = "email=\(useremail)&password=\(userpassword)"
        print(postString)
        request.httpBody = postString.data(using: String.Encoding.utf8)
        
        
        let task = URLSession.shared.dataTask(with: request){
            (data,response,error) in
            if error != nil{
                
                                print("Error is \(String(describing: error))")
                return
            }
            
            if let parseJSON = data {
                do{
                    let jsonObject = try
                        JSONSerialization.jsonObject(with: parseJSON, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                    
                   let resultValue = jsonObject["status"] as! String
                   // print("result: \(resultValue)")
                 //   print(jsonObject["message"])
                    
                 
                    
                    //print(jsonObject["userDetail"])
                    
                    // redirecting the page view according to the response
                    print("result: \(String(describing: resultValue))")
                    DispatchQueue.main.async(execute: {
                    if(resultValue == "Success" && useremail == "niumanager@niu.edu" ){
                            DispatchQueue.main.async(execute: {
                            let mgrViewController:ManagerhomeViewController = self.storyboard?.instantiateViewController(withIdentifier: "A") as! ManagerhomeViewController
                            self.present(mgrViewController, animated: true, completion: nil)

                        })
                    }
                    else if(resultValue == "Success" && useremail != "niumanager@niu.edu"){
                        DispatchQueue.main.async(execute: {
                            let  stfViewController:StaffHomeViewController = self.storyboard?.instantiateViewController(withIdentifier: "B") as! StaffHomeViewController
                            stfViewController.name = useremail
                            self.present(stfViewController, animated: true, completion: nil)
                            
                        })
                    }
                    else{
                        let myalert = UIAlertController(title: "Alert", message: "User Credentials are wrong!! Try Again!!", preferredStyle: UIAlertControllerStyle.alert)
                        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default){ action in
                            //self.dismiss(animated: true, completion: nil)
                        }
                        myalert.addAction(okAction)
                        self.present(myalert, animated: true, completion: nil)
                    }
                    }) //end dispatch
                }//end do
                catch{
                    print(error)
                }
                
            }//end let parseJson
        }//end url session
        
        task.resume()
        
        //Display alert message with confirmation
        
        
        
    }// end json function
    
    // Common function to display an alert message 
    func displayMyAlertMessage(usermessage: String){
        let myalert = UIAlertController(title:"Alert", message: usermessage, preferredStyle: UIAlertControllerStyle.alert)
        let okaction  = UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: nil)
        myalert.addAction(okaction)
        self.present(myalert, animated: true, completion: nil)
    }
        
    
    



}//end class
