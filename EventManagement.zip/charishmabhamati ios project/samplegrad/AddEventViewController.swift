//
//  AddEventViewController.swift
//  samplegrad
//
//  Created by Ios on 12/07/17.
//  Copyright © 2017 charishma bhamati. All rights reserved.
//
/*********************************************************************************************
 GRADUATE PROJECT - AUTHORIZATION SERVICES
 Group       : Charishma Dudde(Z1810220) and Bhamati Pravallika Kuchibhotla(Z1804769)
 
 Purpose     : This project which is an Event management app demonstrates one of the key concepts of Authorization services which is Authentication. Authentication means providing credentials to access the application. Here in this app, 2 roles are presented. Manager and staff. Manager can login and can create events and check events. Staff can log in and and check events assigned to him.
 
 ********************************************************************************************/
import UIKit

class AddEventViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    
    var staff = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Add", style: .plain, target: self, action: #selector(AddEventViewController.AddEventAction(_:)))
        
        loadpickerview()
        createDatePicker()
        
        
        // Do any additional setup after loading the view.
    }
     // this function pops the keyboard when the control is on the amount texfield
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
         view.endEditing(true)
    }
   
    
    //this function dismisses the keyboard when user presses the return key
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        EventNameTextField.resignFirstResponder()
        EventLocationTextField.resignFirstResponder()
        EventDateTextField.resignFirstResponder()
        return true
    }
    
    @IBAction func Cancel(_ sender: UIBarButtonItem) {
        self.performSegue(withIdentifier: "ManagerHome", sender: sender)
    }
    
    
    func loadpickerview(){
        // Fetching FoxSports latest news articles.
        let api_url =
            URL(string:"http://students.cs.niu.edu/~z1810220/ios/currentstaff.php")
        // Create a URL request with the API address
        let urlRequest = URLRequest(url: api_url!)
        // Submit a request to get the JSON data
        let task = URLSession.shared.dataTask(with: urlRequest) {
            (data,response,error) in
            // if there is an error, print the error and do not continue
            if error != nil {
                print(error!)
                //Prints error if any
                return
            } // end if
            // if there is no error, fetch the json formatted content
            if let content = data {
                do {
                    let jsonObject = try
                        JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                    // print(jsonObject)
                    if let articlesJson = jsonObject["result"] as? [[String:AnyObject]]{
                        for item in articlesJson{
                            
                            if let name = item["user_email"] as? String{
                              //  print(name)
                                //self.usersobject.append(users(name:name))
                                self.staff.append(name)
                              
                            } //end if
                            
                        } //end for loop
                        
                    } //end if
                    //if you are using a table view, you would reload the data
                   self.pickerview.reloadAllComponents()
                    
                } // end do
                catch {
                    print(error)
                } // end catch
            } // end if
        } // end getDataSession
        task.resume()

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var EventNameTextField: UITextField!

    @IBOutlet weak var EventLocationTextField: UITextField!
    
    
    @IBOutlet weak var EventDateTextField: UITextField!
    
   
    
    
    let datepicker = UIDatePicker()
    
    
    func createDatePicker(){
        
        
        datepicker.datePickerMode = .dateAndTime
        
        
        //toolbar
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        //bar button item
        let donebutton = UIBarButtonItem(barButtonSystemItem: .done,target: nil, action: #selector(donepressed))
        toolbar.setItems([donebutton], animated: false)
        
        EventDateTextField.inputAccessoryView = toolbar
        
        //assiging date picker to text filed
        EventDateTextField.inputView = datepicker
    }
    
    func donepressed(){
        
        //format date
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        
    // dateformatter.dateStyle = .medium
      //  dateformatter.timeStyle = .medium
        
        
        
        
        EventDateTextField.text = dateformatter.string(from: datepicker.date)
        self.view.endEditing(true)
    }
    
 /*   @IBAction func AddEventAction(_ sender: UIBarButtonItem) {
    }
*/
    @IBAction func AddEventAction(_ sender: UIBarButtonItem) {
        
        let ename = EventNameTextField.text!
        let elocation = EventLocationTextField.text!
        let edate = EventDateTextField.text!
        let estaff = stafflabel.text!
        
        
        if((ename.isEmpty) || (elocation.isEmpty) || (edate.isEmpty)){
            displayMyAlertMessage(usermessage: "All Fields are required")
            return
        }
        
        let sql = "Insert into events (eventname,eventlocation,eventdate,eventstaff) values ('\(ename)','\(elocation)','\(edate)','\(estaff)');"
        
        //print(sql)
        
        
        //send sql to server
        
        let myUrl = URL(string: "http://students.cs.niu.edu/~z1810220/ios/createevent.php")
        var request = URLRequest(url: myUrl!)
        request.httpMethod = "POST"
        
        let postString = "sql=\(sql)"
        request.httpBody = postString.data(using: String.Encoding.utf8)
   
        let task = URLSession.shared.dataTask(with: request){
            (data,response,error) in
            if error != nil{
                
                print("=----------------------")
                print("Error is \(String(describing: error))")
                return
            }
            
            if let parseJSON = data {
                do{
                    let jsonObject = try
                        JSONSerialization.jsonObject(with: parseJSON, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                    
                    let resultValue = jsonObject["status"] as! String
                    print("result: \(resultValue)")
                    
                    if(resultValue == "Success"){
                        DispatchQueue.main.async(execute: {
                            
                            //Display alert message with confirmation
                            
                            let myalert = UIAlertController(title: "Alert", message: "Added Successfully!!", preferredStyle: UIAlertControllerStyle.alert)
                            let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default){ action in
                                self.dismiss(animated: true, completion: nil)
                            }
                            myalert.addAction(okAction)
                            self.present(myalert, animated: true, completion: nil)
                            
                        })//end dispatch
                    }
                    else{
                        DispatchQueue.main.async(execute: {
                            
                            //Display alert message with confirmation
                            
                            let myalert = UIAlertController(title: "Alert", message: "Please Try Again", preferredStyle: UIAlertControllerStyle.alert)
                            let okAction = UIAlertAction(title: "Failed", style: UIAlertActionStyle.default){ action in
                                self.dismiss(animated: true, completion: nil)
                            }
                            myalert.addAction(okAction)
                            self.present(myalert, animated: true, completion: nil)
                            
                        })//end dispatch
                        

                    } //end else
                    
                   // print(jsonObject["message"])
                   // print("result: \(String(describing: resultValue))")
                    
                }//end do
                catch{
                    print(error)
                }
                
            }//end let parseJson
        }//end url session
        
        task.resume()
        
        //Display alert message with confirmation
        
        
    }
    
    
        
    
    func displayMyAlertMessage(usermessage: String){
        let myalert = UIAlertController(title:"Alert", message: usermessage, preferredStyle: UIAlertControllerStyle.alert)
        let okaction  = UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: nil)
        myalert.addAction(okaction)
        self.present(myalert, animated: true, completion: nil)
    }
    
    //@IBOutlet weak var stafflabel: UILabel!
    
    
    @IBOutlet weak var stafflabel: UILabel!
    
    
    
    @IBOutlet weak var pickerview: UIPickerView!
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return staff[row] 
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        //print(staff.count)
        return staff.count
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        stafflabel.text = staff[row]
    }
    }
    
