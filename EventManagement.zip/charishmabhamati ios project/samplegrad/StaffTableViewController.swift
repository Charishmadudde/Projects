//
//  StaffTableViewController.swift
//  samplegrad
//
//  Created by Ios on 4/15/17.
//  Copyright © 2017 charishma bhamati. All rights reserved.
//

/*********************************************************************************************
 GRADUATE PROJECT - AUTHORIZATION SERVICES
 Group       : Charishma Dudde(Z1810220) and Bhamati Pravallika Kuchibhotla(Z1804769)
 
 Purpose     : This project which is an Event management app demonstrates one of the key concepts of Authorization services which is Authentication. Authentication means providing credentials to access the application. Here in this app, 2 roles are presented. Manager and staff. Manager can login and can create events and check events. Staff can log in and and check events assigned to him.
 
 ********************************************************************************************/

import UIKit

class StaffTableViewController: UITableViewController {
    var eventsObject=[events]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchJSONdata()
        
    }
    //user email
    var name:String!
    
    func fetchJSONdata(){
        
        
        // Fetches data of the person and get the json object and add the data to events object so that the table can be viewed
        let api_url=URL(string: "http://students.cs.niu.edu/~z1810220/ios/staffevents.php")
        
        let sql: String = "select * from events where eventstaff = '\(name!)';"
        
        
        var request = URLRequest(url: api_url!)
        request.httpMethod = "POST"
        
        let postString = "sql=\(sql)"
        request.httpBody = postString.data(using: String.Encoding.utf8)

        
        //create a URL request with API addreess
                //submit a request to get the JSOn data
        
        let task = URLSession.shared.dataTask(with: request){
            (data,response,error) in
            if error != nil{
                
                //print("=----------------------")
                print("Error is \(String(describing: error))")
                return
            }
        
        
            if let content=data{
                
               // print("Values start from now")
                do{
                    let jsonObject = try
                        JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                    
                   // print(jsonObject)
                 // print(jsonObject["sql"] as! String)
                    
                    if let resultjson = jsonObject["result"] as? [[String:AnyObject]] {
                        //print(resultjson["eventdate"])
                        for item in resultjson{
                            //Reads the json data and add to event object
                            if let eventid = item["eventid"], let eventname = item["eventname"] as? String, let eventlocation = item["eventlocation"] as? String, let eventdate = item["eventdate"] as? String , let eventstaff = item["eventstaff"] as? String{
                                
                                self.eventsObject.append(events(eventid:eventid as! String, eventname: eventname, eventlocation: eventlocation,eventdate: eventdate, eventstaff: eventstaff))
                                
                                //print(items: Any...)
                            } //end if
                            
                            
                        } //end for loop
                      
                        
                        
                        
                        
                    }
                    
                    //if you are using a table view, you would reload the data
                    self.tableView.reloadData()
                    
                    
                    print("view did load")
                    print(self.eventsObject.count)
                    if(self.eventsObject.count==0){
                        DispatchQueue.main.async(execute: {
                            
                            
                            //diplays alert if no event is displayed
                            
                            let myalert = UIAlertController(title:"Alert", message: "No Events for you", preferredStyle: UIAlertControllerStyle.alert)
                            let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default){ action in
                                self.dismiss(animated: true, completion: nil)
                            }
                            
                            myalert.addAction(okAction)
                            self.present(myalert, animated: true, completion: nil)
                            
                            
                            
                            // navigationController?.popViewController(animated: true)
                            
                            
                            
                        })
                    }
                    
                    
                    
                    
                }//end do
                catch{
                    print(error)
                }//end catch
            }//end else if
            
        }//end get data session
        task.resume()
        
        
        
    }//end fecthJsondata function
    

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return self.eventsObject.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
        
    {
        
        //allocate the table view cell with the values
        
        let cell:staffTableViewCell = tableView.dequeueReusableCell(withIdentifier: "CELL1", for: indexPath) as! staffTableViewCell
        
        let event:events = eventsObject[indexPath.row]
        
        // Configure the cell...
        
        cell.Eventname.text = event.eventname
        cell.eventTimelabel.text = event.eventdate
        
        return cell
    }
    //passes data to detail view controller
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        // Get the new view controller using segue.destinationViewController.
        if(segue.identifier=="staffdetailview" ){
            let detailVC=segue.destination as! StaffDetailViewController
            
            //sending data to the view controller
            if let indexPath=self.tableView.indexPathForSelectedRow{
                let eve:events=eventsObject[indexPath.row]
                
                
                detailVC.eventname = eve.eventname
                detailVC.eventtime = eve.eventdate
                detailVC.eventlocation = eve.eventlocation
                detailVC.eventstaff = eve.eventstaff
                
            }
        }
        
        if(segue.identifier=="BackToStaffHome"){
            let staffHomeView=segue.destination as! StaffHomeViewController
            
            //passsing the user login email
            staffHomeView.name=name
            
        }
        // Pass the selected object to the new view controller.
    }

    

}
