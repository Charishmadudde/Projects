//
//  RegisterViewController.swift
//  samplegrad
//
//  Created by Ios on 12/08/17.
//  Copyright © 2017 charishma bhamati. All rights reserved.
//

/*********************************************************************************************
 GRADUATE PROJECT - AUTHORIZATION SERVICES
 Group       : Charishma Dudde(Z1810220) and Bhamati Pravallika Kuchibhotla(Z1804769)
 
 Purpose     : This project which is an Event management app demonstrates one of the key concepts of Authorization services which is Authentication. Authentication means providing credentials to access the application. Here in this app, 2 roles are presented. Manager and staff. Manager can login and can create events and check events. Staff can log in and and check events assigned to him.
 
 ********************************************************************************************/

import UIKit

class RegisterViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
  
    
    @IBAction func cancelRegister(_ sender: UIButton) {
        //self.performSegue(withIdentifier: "cancelRegister", sender: sender)
    }
    

    @IBOutlet weak var userEmailTextfield: UITextField!
    
    
    @IBOutlet weak var userpasswordtextfield: UITextField!
    
    
     @IBOutlet weak var reapeatpasswordtextfield: UITextField!
    
    
    
    // this function pops the keyboard when the control is on the amount texfield
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    //this function dismisses the keyboard when user presses the return key
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        userEmailTextfield.resignFirstResponder()
        userpasswordtextfield.resignFirstResponder()
        reapeatpasswordtextfield.resignFirstResponder()
        
        return true
    }

/*
This function performs the registering a user//
 
 */
    @IBAction func RegisterButtonTapped(_ sender: UIButton) {
        
        let useremail = userEmailTextfield.text!
        let userpassword = userpasswordtextfield.text!
        let userrepeatpsd = reapeatpasswordtextfield.text!

        
        //check for empty fields
        if(useremail.isEmpty || (userpassword.isEmpty) || (userrepeatpsd.isEmpty))
        {
            //Display Alert Message
            displayMyAlertMessage(usermessage: "All Fields are required")
            
            return
        }
        
        //check if passwords match
        if(userpassword != userrepeatpsd){
            //Display alert messgae
            displayMyAlertMessage(usermessage: "Passwords didnot match")
            
            return
        }
    
        
   /*************************************************
 
            REGISTER
 
 ********************************************/
        
        //Send data to server side. and get the response from server and accordingly it registers user
        
        let myUrl = URL(string: "http://students.cs.niu.edu/~z1810220/ios/userRegister.php")
        var request = URLRequest(url: myUrl!)
        request.httpMethod = "POST"
        
        let postString = "email=\(useremail)&password=\(userpassword)"
        
        print(postString)
        request.httpBody = postString.data(using: String.Encoding.utf8)

        
        let task = URLSession.shared.dataTask(with: request){
           (data,response,error) in
            if error != nil{
                print("=----------------------")

                print("Error is \(String(describing: error))")
                return
            }
            
          

            
            if let parseJSON = data {
               
              //  var jsonObject:AnyObject! = nil
                do{
                     print("Entry into json func")
                    let jsonObject = try
                        JSONSerialization.jsonObject(with: parseJSON, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                    
            
                let resultValue = jsonObject["status"] as! String
                print("result: \(resultValue)")
                
                var isUserRegistered:Bool = false
                //if success, user id is not present already, then application allows to register
                if(resultValue == "Success"){
                        isUserRegistered = true
                }
                    var messageToDisplay : String!
                if(!isUserRegistered){
                    
                    messageToDisplay = jsonObject["message"] as! String
                }// end if user
                //print("message is")
                    // print(jsonObject["xx"] as! NSDictionary)
                   
                DispatchQueue.main.async(execute: {
                    
                    
                    //Display alert message with confirmation and takes back to login page so that user can login
                   
                    let myalert = UIAlertController(title: "User Registered SuccessFully", message: messageToDisplay, preferredStyle: UIAlertControllerStyle.alert)
                    
                    let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default){ action in
                         self.dismiss(animated: true, completion: nil)
                       
                        let  loginViewController:LoginViewController = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
                        
                        self.present(loginViewController, animated: false, completion: nil)
                    }
                    
                    myalert.addAction(okAction)
                    self.present(myalert, animated: true, completion: nil)
                    
                })
                    //end dispatch
                }//end do
                catch{
                    print("--------")
                   // print(jsonObject!)
                    
                    print(error)
                }
            }//end let parseJson
        }//end url session
        
        task.resume()
        //Display alert message with confirmation
   
    }// end json function
    
    // Common function to display an alert message 
    func displayMyAlertMessage(usermessage: String){
        let myalert = UIAlertController(title:"Alert", message: usermessage, preferredStyle: UIAlertControllerStyle.alert)
        let okaction  = UIAlertAction(title: "OK", style: UIAlertActionStyle.default,handler: nil)
        myalert.addAction(okaction)
        self.present(myalert, animated: true, completion: nil)
    }
  

}
