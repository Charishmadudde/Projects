//
//  ViewController.swift
//  Tip Calculator
//
//  Created by Charishma Dudde (z1810220) and Bhamati Pravallika Kuchibotla (z1804769) on 10/12/17.
//  Copyright © 2017 Charishma & Pravallika. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    var totalBillAmount = 0.0                   //variable to store the final bill amount
    var billAmount: Double = 0.0                //variable to store the initial bill amount
    let stepValue: Float = 5                    //variable to store the slider step value

    //Outlets
    @IBOutlet weak var billAmountText: UITextField!
    @IBOutlet weak var tipPercentSlider: UISlider!
    @IBOutlet weak var partySizeSlider: UISlider!
    @IBOutlet weak var tipPercentLabel: UILabel!
    @IBOutlet weak var tipAmountLabel: UILabel!
    @IBOutlet weak var partySizeLabel: UILabel!
    @IBOutlet weak var individualTipLabel: UILabel!
    
    //This function is triggered when tip percent slider is moved
    @IBAction func tipPercentChanged(_ sender: UISlider) {
        
        //this let's the slider to move in 5 steps
        let adjustedValue = round(sender.value / stepValue) * stepValue
        sender.value = adjustedValue
        
        //Checking if the UITextField is empty, if not execute this
        if let billAmountString = billAmountText.text, !billAmountString.isEmpty {
            
            billAmount = Double(billAmountString)!      //typecasting to double from a string
            let tipPercent = Int(sender.value)          //getting the tip percent from the UISlider
            
            //calculating the final amount by adding tip to the initial bill
            totalBillAmount = billAmount + ((billAmount) * (Double(tipPercent)/100))
            
            //formatting the display string of the final amount to be paid
            let totalBillAmountString = String(format: "$%.02f", totalBillAmount)
            tipAmountLabel.text = totalBillAmountString
            
            //formatting the display string of the tip percentage
            let tipString = String(format: "%d%%", tipPercent)
            tipPercentLabel.text = tipString
        }
        else //if the UITextField is empty, display an error alert
        {
            let alertController = UIAlertController(title: "Error!", message: "Please enter a bill amount!", preferredStyle: UIAlertControllerStyle.alert)
            let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil)
            
            alertController.addAction(okAction)
            
            self.present(alertController, animated: true)
        }
        
    }
    
    @IBAction func partySizeChanged(_ sender: UISlider) {
        
        let partySize = Int(partySizeSlider.value)      //typecasting to an integer from string
        let individualTip = totalBillAmount / Double(partySize) //calculating the share of the each individual
        
        //formatting the display string of the individual tip amount
        let individualTipString = String(format: "$%.02f", individualTip)
        individualTipLabel.text = individualTipString
        
        partySizeLabel.text = String(partySize)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.billAmountText.delegate = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Hiding keyboard when user touches outside keyboard
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
}

