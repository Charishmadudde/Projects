//
//  ViewController.swift
//  Assign1
//
//  Created by Charishma Dudde on 10/2/17.
//  Copyright © 2017 Charishma Dudde. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var resultDisplay: UILabel!
    @IBOutlet weak var textField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }

    @IBAction func pressMe(_ sender: Any) {
        textField.resignFirstResponder()
        self.resultDisplay.text = ""
        if (textField.text?.isEmpty)! {
            let alertController = UIAlertController(title: "Error", message: "Please enter an age for your dog", preferredStyle: .alert)
            let action = UIAlertAction(title: "OK", style: .default) {
                UIAlertAction in
                alertController.dismiss(animated: true, completion: nil)
            }
            alertController.addAction(action)
            self.present(alertController, animated: true, completion: nil)
        }
        else if (Int(textField.text!)! == 0) {
            let alertController = UIAlertController(title: "Error", message: "Invalid Age Entered", preferredStyle: .alert)
            let action = UIAlertAction(title: "OK", style: .default) {
                UIAlertAction in
                alertController.dismiss(animated: true, completion: nil)
            }
            alertController.addAction(action)
            self.present(alertController, animated: true, completion: nil)
        }
        else {
            let textfield = Int(textField.text!)
            var result = 0
            if(textfield == 1)
            {
                result = 15;
            }
            else if(textfield == 2)
            {
                result = 24;
            }
            else{
                result = 24 + (textfield!-2)*5;
            }
            resultDisplay.text = "Your dog is \(result) in human years"
            }
    }

}

